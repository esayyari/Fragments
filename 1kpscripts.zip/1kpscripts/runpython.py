#!/usr/bin/env python

import sys

import pylauncher

pylauncher.ClassicLauncher(sys.argv[1],cores=int(sys.argv[2]))
